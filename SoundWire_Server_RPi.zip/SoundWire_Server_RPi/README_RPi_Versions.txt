Please choose which version of SoundWire Server for Raspberry Pi you wish
to install:

SoundWire_Server_RPi_GUI.tar.gz  - SoundWire Server version 3.0+. Uses Qt5 for
   its GUI. Built for Raspberry Pis running Raspbian Stretch or later, may work
   on earlier Raspbian versions. Can run without a GUI window but requires Qt5
   libraries to be installed.

SoundWire_Server_RPi_cmdline.tar.gz  - SoundWire Server version 2.1.2. This
   version uses the command line only, no GUI. It is suitable for minimal
   systems with no desktop manager or older Raspberry Pi models (e.g. 1 & 2). 
